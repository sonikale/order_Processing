// const stripe = require('./stripe'); // Import the configured Stripe instance
const stripe = require('stripe')('sk_test_51OcNUgSFeG5l20FbT4U3s510FHxpKKrMHMGx5qsWYFVVnO8YUDRpIBoSvMxYYuDMWrGEdjMVA6lahSWZ0awCxc6T00uvwJyDKG');

// Use this key on the client side
const publishableKey = 'pk_test_51OcNUgSFeG5l20FbZH1JNISXDCZIBecUUEODkZNG0msG5BmHoTLhy4UOrg2PVNrAmh9QJieDY9ij8sjd0JQhdW0Z00tajQSf94';

module.exports = stripe;

