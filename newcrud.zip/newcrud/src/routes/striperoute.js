const express = require('express');
const router = express.Router();
const Product = require('../model/productModel.js');
const User = require('../model/userModel.js');
const Order = require('../model/orderModel.js');
const stripeCustomerModel = require('../model/stripeCustomer.js');
const stripeSubscription = require('../model/subscriptionModel.js');
const Schema = require('../common/validation.js');
const StatusCodes = require('http-status-codes');
const stripeKey = require('../stripe/stripe.js');
const stripe = require('../stripe/middleware.js');
const { validateToken } = require('../common/authMiddleware.js');
const Stripe = require('stripe');
const newstripekey = new Stripe('sk_test_51OcNUgSFeG5l20FbT4U3s510FHxpKKrMHMGx5qsWYFVVnO8YUDRpIBoSvMxYYuDMWrGEdjMVA6lahSWZ0awCxc6T00uvwJyDKG', { maxNetworkRetries: 2 });
const { errorResponse, successResponse } = require('../common/respoanceapi.js');

// Create Stripe Customer 
router.post('/createStripeCustomer', async (req, res) => {
    try {
        let result = {};

        console.log('create stripe customer API start');
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {

            const stripeCustomer = await stripeCustomerModel.findOne({ email: req.body.email });
            console.log(stripeCustomer);
            if (!stripeCustomer) {
                result = await stripe.createCustomer(req.body);
                const stripeCustPayload = {
                    userId: validateTokenResult.userDetails._id,
                    customerId: result.id,
                    email: result.email,
                    name: result.name,
                    strpCreated: new Date()
                };
                await stripeCustomerModel.create(stripeCustPayload);
                res.json(successResponse('stripe customer created successfully.', result, 201))

            } else {
                res.json(errorResponse('stripe customer already created.', stripeCustomer, 200))
            }
        } else {
            result = validateTokenResult;
            res.json(errorResponse(validateTokenResult, {}, 422))
        }

    } catch (error) {
        console.log(error)
        res.json(errorResponse('Internal Server Error', error, 500))
    }
});

// retrive Stripe Customer 
router.get('/retriveCustomer', async (req, res) => {
    try {
        console.log('retrive customer API start');
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {

            const retriveCustomer = await stripe.retrieveCustomer(req.query.customerId);
            res.json(successResponse('retrive stripe customer', retriveCustomer, 201))

        } else {
            result = validateTokenResult;
            res.json(errorResponse(validateTokenResult, {}, 422))
        }
    } catch (error) {
        console.log(error)
        res.json(errorResponse('Internal Server Error', error, 500))
    }
});

//charge customer throgh customer Id
router.post('/chargeCustomer', async (req, res) => {
    try {
        console.log('add card to customer');
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {
            let payload = {
                amount: req.body.amount,
                currency: req.body.currency,
                description: req.body.description,
                customer: req.body.customer
            }

            const stripecharge = await newstripekey.charges.create(payload);
            console.log(stripecharge);
            res.json(successResponse('stripe token created', stripecharge, 200))

        } else {
            result = validateTokenResult;
            res.json(errorResponse(validateTokenResult, {}, 422))
        }
    } catch (error) {
        console.log(error)
        res.json(errorResponse('Internal Server Error', error, 500))
    }
});
//get subscription list
router.get('/getsubscriptionlist', async (req, res) => {
    try {
        console.log("Get subscription list API Start");
        const validateTokenResult = await validateToken(req, res);

        if (!validateTokenResult.error) {
            const validSchema = Schema.validateRequest(Schema.getSubscriptionList, req.body);
            if (validSchema.isValidRequest) {
                const subscriptionList = await stripe.getSubscriptionList(req.body.planId);
                // result = successResponse("Fetched subscription list sucessfully.", subscriptionList, StatusCodes.OK);
                res.json(successResponse('subscription list ', subscriptionList, 200))

            } else {
                res.json(errorResponse(validSchema.error, {}, 422))
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.log("Get subscription list API Error: " + error);
        res.json(errorResponse('Internal Server Error', error, 500))
    }
})

//create stripe subscription api
router.post('/createstripesubcription', async (req, res) => {
    try {
        console.log("Create Stripe Subscription API Start");
        const validateTokenResult = await validateToken(req, res);

        if (!validateTokenResult.error) {
            const validSchema = Schema.validateRequest(Schema.createSubscription, req.body);
            if (validSchema.isValidRequest) {
                const subscription = await stripe.createSubscription(req.body.customerId, req.body.priceId, req.body.coupon);
                let subscriptionPayload = {
                    userId: validateTokenResult.userDetails._id,
                    customerId: req.body.customerId,
                    subscriptionId: subscription.id,
                    productId: req.body.priceId,
                    couponId: req.body.coupon,
                    couponCode: req.body.couponCode,
                    subscriptionStatus: subscription.status,
                    subscriptionEndDate: new Date(subscription.current_period_end * 1000),
                    message: "Subscription created"
                }
                await stripeSubscription.create(subscriptionPayload);
                res.json(successResponse("Subscribed successfully.", subscription, 200))

            } else {
                console.log('Invalid Schema. Details:', validSchema.error);
                res.json(errorResponse(validSchema.error, {}, 422))
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.log("Create Stripe Subscription API Error: ", error);
        res.json(errorResponse('Internal Server Error', error, 500))
    }
})

//cansel api for strioe subscription
//create stripe subscription api
router.post('/cancelSubscription', async (req, res) => {
    try {
        console.log("Cancel subscription API Start");
        const validateTokenResult = await validateToken(req, res);

        if (!validateTokenResult.error) {
            const validSchema = Schema.validateRequest(Schema.cancelSubscription, req.body);
            if (validSchema.isValidRequest) {
                const canceledSubscription = await stripe.cancelSubscription(req.body.subscriptionId);
                await stripeSubscription.updateOne({ subscriptionStatus: 'active', subscriptionId: req.body.subscriptionId }, { $set: { subscriptionStatus: canceledSubscription.status, message: 'Subscription cancelled', cancelReason: req.body.reason } },
                );
                console.log('Cancelled subscription successfully. Details: ', canceledSubscription);
                res.json(successResponse("Subscription cancelled successfully.", canceledSubscription, 200))


            } else {
                res.json(errorResponse(validSchema.error, {}, 422))
            }
        } else {

            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.log("Cancel subscription API Error: " + error);
        res.json(errorResponse('Internal Server Error', error, 500))

    }
})


//get product list
router.get('/getmysubscription', async (req, res) => {
    try {
        console.log("Get product list API Start");
        const validateTokenResult = await validateToken(req, res);

        if (!validateTokenResult.error) {
            let mySubscriptionObj = {
                productList: await stripe.getProductList()
            }
            const couponList = await stripe.getCouponList();

            const subscriptionDetails = await stripeSubscription.findOne({ userId: validateTokenResult.userDetails._id });
            console.log("subscriptionDetails>>>>>>>>>", subscriptionDetails)
            if (subscriptionDetails) {
                mySubscriptionObj.activeSubscription = await stripe.getActiveSubscription(subscriptionDetails.customerId);
            }
            mySubscriptionObj.couponList = couponList;
            res.json(successResponse("Subscription  successfully." , mySubscriptionObj, 200))

        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.log("Get my subscription list API Error: ", error);
        res.json(errorResponse('Internal Server Error', error, 500))
    }
})

//create token
router.post('/createtoken', async (req, res) => {
    try {
        console.log('add card to customer');
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {
            let param = {};
            param.card = {
                number: req.body.number,
                exp_month: req.body.exp_month,
                exp_year: req.body.exp_year,
                cvc: req.body.cvc
            }

            const stripetoken = await newstripekey.tokens.create(param);
            console.log(stripetoken);
            res.json(successResponse('stripe token created' , stripetoken, 200))

        } else {
            result = validateTokenResult;
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.log(error)
        res.json(errorResponse('Internal Server Error', error, 500))
    }
});

//add card to customer
router.post('/addcardtocustomer', async (req, res) => {
    try {
        console.log('add card to customer');
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {

            const customerId = req.body.customerId;
            const sourceToken = req.body.token;
            const stripetoken = await newstripekey.customers.createSource(customerId, { source: sourceToken });
            console.log(stripetoken);
            res.json(successResponse('stripe token created' , stripetoken, 200))
        } else {
            result = validateTokenResult;
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.log(error)
        res.json(errorResponse('Internal Server Error', error, 500))
    }
});

module.exports = router;
