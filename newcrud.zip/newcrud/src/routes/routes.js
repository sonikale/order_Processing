// routesjs
const express = require('express');
const router = express.Router();
const Product = require('../model/productModel');
const User = require('../model/userModel');
const Order = require('../model/orderModel');
const Schema = require('../common/validation');
const StatusCodes = require('http-status-codes');
const stripe = require('../stripe/stripe');
const jwt = require('jsonwebtoken');
const createError = require('http-errors');
const { errorResponse, successResponse } = require('../common/respoanceapi');
const { createJwtToken, validateToken } = require('../common/authMiddleware');

// Product Management
//add product API
router.post('/addproducts', async (req, res) => {
    let result = '';
    try {
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {
            const validSchema = Schema.validateRequest(Schema.productSchema, req.body);
            if (validSchema.isValidRequest) {
                //add here valid req.body function means valid schema 
                result = new Product(req.body);
                let saveresult = await result.save();
                console.log('result', result);
                if (saveresult) {
                    res.json(successResponse('Product added successfully.', saveresult, 201));
                } else {
                    res.json(errorResponse('Failed to save the product.', {}, 500));
                }

            } else {
                res.json(errorResponse(validSchema.error, {}, 422))
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))

        }
    } catch (error) {
        res.json(errorResponse('Internal Server Error', error, 500))
    }
});


router.put('/updateproducts', async (req, res) => {
    try {
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {

            const validSchema = Schema.validateRequest(Schema.updateproductSchema, req.body);
            if (validSchema.isValidRequest) {
                const result = await Product.updateOne(
                    { _id: req.body.productId }, // Assuming you are updating a product by its ID
                    { $set: { name: req.body.name, description: req.body.description, price: req.body.price, quantity: req.body.quantity } }
                );
                // Check the result and send an appropriate response
                if (result) {
                    res.json(successResponse('Product updated successfully.', result, 200))

                } else {
                    res.json(errorResponse('Product not found or not updated.', {}, 422))

                }
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.error('Error updating product:', error);
        res.json(errorResponse('Internal Server Error', error, 500))
    }
});


router.get('/getAllproductList', async (req, res) => {
    const validateTokenResult = await validateToken(req, res);
    if (!validateTokenResult.error) {
        const result = Product.find().sort();
        // Execute the query and handle the results
        result.then((documents) => {
            // Now you can log or stringify the actual data
            console.log(JSON.stringify(documents));
            res.json(successResponse("Get the Product filter list", documents, 200))

        }).catch((error) => {
            res.json(errorResponse('Internal Server Error', error, 422))
        });
    }
    else {
        res.json(errorResponse(validateTokenResult.error, {}, 422))

    }
});

router.delete('/deleteProduct', async (req, res) => {
    try {
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {
            const productId = { _id: req.query.productId };
            // Use deleteOne to delete a product by its ID
            const result = await Product.updateOne(productId, { $set: { isDelete: true } }); // soft delete case
            // Check the result and send an appropriate response
            if (result.deletedCount > 0) {
                res.json(successResponse('Product deleted successfully.', documents, 200))

            } else {
                res.json(errorResponse('Product not found or not deleted.', error, 405))
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, error, 422))

        }
    } catch (error) {
        console.error('Error deleting product:', error);
        res.json(errorResponse('Internal Server Error', error, 500))
    }
});

// User Registration
router.post('/users', async (req, res) => {
    let result = '';
    try {

        const emailExist = await User.findOne({ email: req.body.email });
        if (emailExist) throw createError.Conflict("Email already exists, try using another email");
        const validSchema = Schema.validateRequest(Schema.userSchema, req.body);
        if (validSchema.isValidRequest) {
            result = new User(req.body);
            result['token'] = createJwtToken({ email: req.body.email });
            let saveresult = await result.save();
            if (saveresult) {
                res.json(successResponse('User added successfully.', result, 201))
            } else {
                res.json(errorResponse('Failed to save the user.', {}, 500));
            }
        } else {
            res.json(errorResponse(validSchema.error, error, 422))
        }
    } catch (error) {
        console.log(error)
        if (error.code === 11000) {
            // Duplicate key error, handle accordingly
            res.json(errorResponse('Duplicate key error. User with this username or email already exists.', error, 400));
        } else {
            res.json(errorResponse('Internal Server Error', error, 500))
        }
    }
});

router.delete('/deleteUser', async (req, res) => {
    try {
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {
            const userId = { _id: req.query.userId };
            // Use deleteOne to delete a product by its ID
            const result = await User.updateOne(userId, { $set: { isDelete: true } }); // soft delete case

            // Check the result and send an appropriate response
            if (result.deletedCount > 0) {
                res.json(successResponse('User deleted successfully.', result, 200))
            } else {
                res.json(errorResponse('User not found or not deleted.', error, 422))
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))

        }
    } catch (error) {
        console.error('Error deleting product:', error);
        res.json(errorResponse('Internal Server Error', {}, 500))
    }
});

// Place Order
router.post('/addorders', async (req, res) => {
    try {
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {
            const validSchema = Schema.validateRequest(Schema.ordertSchema, req.body);
            if (validSchema.isValidRequest) {
                //added here userid get in beaer token
                const order = new Order({
                    user: validateTokenResult.userDetails._id,
                    products: req.body.products,
                    totalAmount: req.body.totalAmount,
                });
                let saveresult = await order.save();
                if (saveresult) {
                    res.json(successResponse('Order added successfully.', order, 201))
                } else {
                    res.json(errorResponse('Failed to save the order.', {}, 500));
                }

            } else {
                res.json(errorResponse(validSchema.error, {}, 422))
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }


    } catch (error) {
        res.json(errorResponse('Internal Server Error', {}, 500))
    }
});

//get orders
router.get('/getorders', async (req, res) => {
    const validateTokenResult = await validateToken(req, res);
    if (!validateTokenResult.error) {
        const result = Order.find().sort();
        // Execute the query and handle the results
        result.then((documents) => {
            // Now you can log or stringify the actual data
            console.log(JSON.stringify(documents));
            res.json(successResponse("Get the Product filter list", documents, 200))
        }).catch((error) => {
            res.json(errorResponse('Internal Server Error', {}, 500))
        });
    } else {
        res.json(errorResponse(validateTokenResult.error, {}, 422))
    }
});

//update orders only amount
router.put('/updateorderamount', async (req, res) => {
    try {
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {
            const result = await Order.updateOne(
                { _id: req.body.orderId }, // Assuming you are updating a product by its ID
                { $set: { totalAmount: req.body.totalAmount } }
            );
            // Check the result and send an appropriate response
            console.log(result);
            if (result.modifiedCount > 0) {
                res.json(successResponse('Order updated successfully.', {}, 200));
            } else {
                res.json(errorResponse('Order not found or not updated.', {}, 422));
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.error('Error updating product:', error);
        res.json(errorResponse('Internal Server Error', {}, 500))
    }
});

router.delete('/deleteOrder', async (req, res) => {
    try {
        const validateTokenResult = await validateToken(req, res);
        if (!validateTokenResult.error) {
            const orderId = { _id: req.query.orderId };
            // Use deleteOne to delete a product by its ID
            const result = await Order.updateOne(orderId, { $set: { isDelete: true } }); // soft delete case

            // Check the result and send an appropriate response
            if (result.deletedCount > 0) {
                res.json(successResponse('Order deleted successfully.', {}, 200));
            } else {
                res.json(successResponse('Order not found or not deleted.', {}, 422));
            }
        } else {
            res.json(errorResponse(validateTokenResult.error, {}, 422))
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        res.json(errorResponse('Internal Server Error', {}, 500))
    }
});


// Endpoint to create a PaymentIntent
router.post('/create-payment-intent', async (req, res) => {
    const { items } = req.body;

    const paymentIntent = await stripe.paymentIntents.create({
        amount: calculateOrderAmount(items),
        currency: 'usd',
    });

    res.json(successResponse(paymentIntent.client_secret, {}, 200));

});

function calculateOrderAmount(items) {
    // Calculate the order amount based on the items
    // Replace this with your actual logic
    return 1000;
}

router.post("/create-checkout-session", async (req, res) => {
    const { product } = req.body;
    const session = await stripe.checkout.sessions.create({
        payment_method_types: ["card"],
        line_items: [
            {
                price_data: {
                    currency: "inr",
                    product_data: {
                        name: product.name,
                    },
                    unit_amount: product.price * 100,
                },
                quantity: product.quantity,
            },
        ],
        mode: "payment",
        success_url: "http://localhost:3000/success",
        cancel_url: "http://localhost:3000/cancel",
    });
    res.json(successResponse(session.id, {}, 200));

});

async function createPaymentMethod(payment_method) {
    return await stripe.paymentMethods.create({
        type: 'card',
        card: {
            number: payment_method.cardNumber,
            exp_month: payment_method.expMonth,
            exp_year: payment_method.expYear,
            cvc: payment_method.cvc,
        },
    });
}



router.delete('/login', async (req, res) => {
    try {
        console.log("Login API Start");

        const validSchema = Schema.validateRequest(Schema.login, req.body);
        if (validSchema.isValidRequest) {
            const user = await User.findOne({ username: req.body.userName });

            if (!user) throw createError.Conflict('Please enter valid username or password');
            const isSame = await bcryptjs.compare(req.body.password, user.password);
            if (isSame) {
                res.json({ success: true, message: 'User Login successfully.', status: 200, data: user });
            } else {
                throw createError.Conflict('Please enter valid username or password');
            }
        } else {
            res.json({ success: false, message: 'Internal Server Error', status: 400, data: validSchema });
        }
    } catch (error) {
        console.error('Error deleting product:', error);
        res.status(500).json({ success: false, message: 'Internal Server Error' });
    }
});

module.exports = router;
