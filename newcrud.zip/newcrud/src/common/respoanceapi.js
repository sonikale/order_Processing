function successResponse(msg, data, status) {
    return {
        message: msg,
        success: true,
        statusCode: status,
        result: data
    };
}

function errorResponse(msg, error, status) {

    return {
        message: msg,
        statusCode: status,
        success: false,
        data: error
    };
}

module.exports = { successResponse, errorResponse };
