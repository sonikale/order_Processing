const Joi = require('joi');


const validateRequest = (schema, reqBody) => {
    if (Joi.isSchema(schema)) {
        const { error } = schema.validate(reqBody);
        const valid = error == null;

        if (valid) {
            return { isValidRequest: true };
        } else {
            const { details } = error;
            const message = details.map(i => i.message).join(',');
            return { isValidRequest: false, error: message };
        }
    } else {
        return { isValidRequest: false, error: 'Invalid request.' };
    }
}


// Joi schema for product validation
const productSchema = Joi.object({
    name: Joi.string().required(), // Assuming user is a string (you might use Joi.objectId() if it's an ObjectId)
    description: Joi.string().required(),
    price: Joi.number().required(),
    quantity: Joi.number().required(),
});

// Joi schema for product validation
const updateproductSchema = Joi.object({
    productId: Joi.string().required(),
    name: Joi.string().required(), // Assuming user is a string (you might use Joi.objectId() if it's an ObjectId)
    description: Joi.string().required(),
    price: Joi.number().required(),
    quantity: Joi.number().required(),
});
// Joi schema for order validation
const ordertSchema = Joi.object({
    user: Joi.string().required(), // Assuming user is a string (you might use Joi.objectId() if it's an ObjectId)
    products: Joi.array().required(),
    totalAmount: Joi.number().required(),
});
// Joi schema for order validation
const userSchema = Joi.object({
    username: Joi.string().required(), // Assuming user is a string (you might use Joi.objectId() if it's an ObjectId)
    password: Joi.string().required(),
    email: Joi.string().required(),
});

//Joi schema for subscription
const getSubscriptionList = Joi.object({
    planId: Joi.string().optional().trim()
});

// Joi for the create sub scription
const createSubscription = Joi.object({
    customerId: Joi.string().required().trim(),
    priceId: Joi.string().required().trim(),
    coupon: Joi.string().optional().allow('').trim(),
    couponCode: Joi.string().optional().allow('').trim(),
});
const cancelSubscription = Joi.object({
    subscriptionId: Joi.string().required().trim(),
    reason: Joi.string().required().allow('').trim()
});

const login = Joi.object({
    userName: Joi.string().required().trim(),
    password: Joi.string().required().trim(),
});

module.exports = { productSchema, validateRequest, userSchema, getSubscriptionList, createSubscription, cancelSubscription, ordertSchema, updateproductSchema, login };
