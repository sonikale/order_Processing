// const jwt = require('jsonwebtoken');
const jwt = require('jsonwebtoken');
const User = require('../model/userModel');
const JWT_SECRET = 'vnbsjksajkdcbkjfgblmcv';
const authenticateUser = async (req, res, next) => {
  try {
    const token = req.header('Authorization').replace('Bearer ', '');
    const decoded = jwt.verify(token, JWT_SECRET);
    const user = await User.findOne({ _id: decoded._id, 'tokens.token': token });
    if (!user) {
      throw new Error();
    }
    req.user = user;
    req.token = token;
    next();
  } catch (error) {
    res.status(401).send({ error: 'Please authenticate.' });
  }
};


function createJwtToken(payload) {
  return jwt.sign(payload, JWT_SECRET, { expiresIn: "20days" });
}

function verifyJwtToken(token) {
  try {
    return jwt.verify(token, JWT_SECRET);
  } catch (error) {
    console.log(error);
    return error;
  }
}

const validateToken = async (req, res) => {
  let result = {};
  try {
    console.log('req.headers.authorization.split(" ")[1]', req.headers.authorization.split(" ")[1]);
    const userDetails = await User.findOne({ token: req.headers.authorization.split(" ")[1] });  // check token present in DB
    if (userDetails) {
      const jwtVerifyResult = verifyJwtToken(userDetails.token);
      if (jwtVerifyResult.email) {
        result = { error: false, userDetails };
      } else {
        console.log('Invalid Request for userId:', userDetails.id, ' Details:', jwtVerifyResult);
        res.json({ success: false, message: 'Invalid request for authenticate.', status: 401, data: {} });

      }
    } else {
      console.log('Invalid Request. Database entry not found for Token:', req.headers.authorization.split(" ")[1]);
      res.json({ success: false, message: 'Database entry not found for Token:', status: 404, data: {} });
    }
  } catch (err) {
    console.log('API Error. Details:', err);
    res.json({ success: false, message: 'Something went to wrong', status: 500, data: {} });

  }
  console.log(result)
  return result;
}
module.exports = { authenticateUser, createJwtToken, validateToken, verifyJwtToken };
