const mongoose = require('mongoose');

const stripeCustomerSchema = new mongoose.Schema({

    userId: {
        type: String,
        required: true,
    },
    customerId: {
        type: String,
        required: true,
    },
    email: {
        type: String,
        required: true,
        unique: true
    },
    name: {
        type: String,
        default: null
    },
    strpCreated: {
        type: Date,
        default: Date.now,
        required: true,
        trim: true,
    }
},
    { timestamps: true }
);

const stripeCustomer = mongoose.model('stripeCustomer', stripeCustomerSchema);

module.exports = stripeCustomer;
