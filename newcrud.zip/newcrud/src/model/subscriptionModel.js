const mongoose = require('mongoose');

const stripeSubscriptionSchema = new mongoose.Schema({
   userId: {
    type: String,
    required: true,
    trim: true
  },

  customerId: {
    type: String,
    required: true,
    trim: true
  },

  subscriptionId: {
    type: String,
    required: true,
    trim: true
  },

  productId: {
    type: String,
    required: true,
    trim: true
  },

  couponId: {
    type: String,
    trim: true
  },

  couponCode: {
    type: String,
    trim: true
  },

  subscriptionStatus: {
    type: String,
    required: true,
    trim: true
  },

  subscriptionEndDate: {
    type: Date,
    required: true
  },

  message: {
    type: String,
    required: true,
    trim: true
  },

  cancelReason: {
    type: String,
    trim: true,
    defaultValue: ''
  }
},
  { timestamps: true }
);


const stripeSubscription = mongoose.model('stripeSubscription', stripeSubscriptionSchema);

module.exports = stripeSubscription;
