// Import necessary modules
const express = require('express');
const connectDB = require('./src/common/dbconfig'); // Adjust the path accordingly
const router = require('./src/routes/routes'); // Adjust the path accordingly
const stripeApi = require('./src/routes/striperoute');
// Create an Express application
const app = express();

// Connect to the database
connectDB();
// Middleware to parse JSON in the request body
app.use(express.json());
app.use('/api', router,stripeApi);

// Define a simple route
app.get('/get', (req, res) => {
    res.json({ 'data': 'Hello, this is your Node.js project!' });
});

// Start the server
const port = 3000;
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
